/*
 * myGPIO.h
 *
 */

#ifndef MYGPIO_H_
#define MYGPIO_H_

// Prototypes
void initGPIO(void);


#endif /* MYGPIO_H_ */

