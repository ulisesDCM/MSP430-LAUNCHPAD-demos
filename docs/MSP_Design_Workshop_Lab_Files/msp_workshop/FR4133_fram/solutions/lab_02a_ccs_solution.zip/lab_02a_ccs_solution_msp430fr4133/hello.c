#include <stdio.h>
#include <msp430.h> 

/*
 * hello.c
 */
int main(void) {
    WDTCTL = WDTPW | WDTHOLD;	// Stop watchdog timer

    //FRCTL0 = FRCTLPW | NWAITS_0;
	
	printf("Hello World!\n");
	
	return 0;
}
